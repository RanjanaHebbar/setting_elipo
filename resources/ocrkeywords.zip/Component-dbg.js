sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("ocrkeywords.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);